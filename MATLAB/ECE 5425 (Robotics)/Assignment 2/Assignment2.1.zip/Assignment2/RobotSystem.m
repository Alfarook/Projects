classdef RobotSystem
    %UNTITLED Summary of this class goes here
    %   Detailed explanation goes here

    properties
        model = [];                                  % Initialize robot Serial Link object
        workspaceDimentions = [303, 231]/1000;       % [width, height] in meters
        robotBasePosition = [];                      % [X, Y] in meters 

        startingVariables = [];                       % Starting position of the robot

        flourZactual = 0;                            % Adjected flour Z coordinate


        %%%%Hardware Variables
        device = [];
        servo1 = [];
        servo2 = [];
        servo3 = [];

        %Hardcoded motor clibration. Row corisponds to motor, and columns
        %resprisent slope and intersept respectivelly. DH parameter as a
        %function of motor value (0-1)
        motorCalibration = [-135.78, 125.75; -142.43, 156.55; -27.5, 108.7];              

    end

    methods
        function obj = RobotSystem(robotBasePosition,startingVariables, flourZactual,...
                                   DHparametersAndType, jointsLimits, jointsOffsets)
            %RobotSystem Construct an instance of this class

            obj.robotBasePosition = robotBasePosition;
            obj.startingVariables = startingVariables;
            obj.flourZactual = flourZactual;

            obj.model = obj.createRobotModel(DHparametersAndType, jointsLimits, jointsOffsets);


        end

        function model = createRobotModel(obj, DHparametersAndType, jointsLimits, jointsOffsets)

            % Create robot links using DHparametersAndType,
            % jointsLimits, and jointsOffsets metrices
            for l = 1:size(DHparametersAndType, 1)
                L(l) = Link(DHparametersAndType(l, :));
                L(l).qlim = jointsLimits(l, :);
                L(l).offset = jointsOffsets(l);
            end
            
            % Assigning the robot object
            model = SerialLink(L, 'name', 'robot');

            % Moving the base of the robot to the specified robot base
            model.base = transl(obj.robotBasePosition(1), obj.robotBasePosition(2), 0);

        end

        function plotModel(obj, title, GUIPosition)

            % Configure the figure to plot the robot
            close all                                                   % Close all figures
            fugure1Handle=figure(1);                                    % Get figure handle to configure
            figurePosition = GUIPosition;                               % Start off with the same position as GUI
            figurePosition(1) = figurePosition(1)+figurePosition(3);    % Move figure to the right side of the screen for convenience
            figurePosition(2) = figurePosition(2)-50;                   % Adjust figure y position
            set(fugure1Handle,'Position',figurePosition)                % Apply settings to the figure


            % Plot robot workspace with the clipboard dimensions and
            % scale the elements to look good. Use starting variables as
            % created by the user. Plot robot 2 times for different views
            for i = 1:2
                % Selecting subplot
                subplot(2,1,i)

                obj.model.plot(obj.startingVariables, 'workspace', ...
                    [0, obj.workspaceDimentions(1), ...
                    0, obj.workspaceDimentions(2), ...
                    0, .133 ], 'floorlevel',0, 'scale', .4);
                
                hold on 

                if(i == 1)
                    view ([0 0 90])
                end
            end

            %name subplot
            sgtitle(title);
                
        end

        function ServoValues = robotVariablesToServoValues(obj, variables)
            servo1Value = (variables(1)*180/pi-obj.motorCalibration(1,2))/obj.motorCalibration(1,1);
            servo2Value = (variables(2)*180/pi-obj.motorCalibration(2,2))/obj.motorCalibration(2,1);
            servo3Value = (variables(3)*1000-obj.motorCalibration(3,2))/obj.motorCalibration(3,1);

            ServoValues = [servo1Value, servo2Value, servo3Value];
        end

        function moveToPosition(obj, variables)
            % Remember previous variables by performing calling getpos
            lastVariables = obj.model.getpos();

            % Plotting the robot with the new variables
            obj.model.animate(variables);

            %try to move physical robot
            if(~isempty(obj.device))
                servoValues = obj.robotVariablesToServoValues(variables);
                obj.servo1.writePosition(servoValues(1));
                obj.servo2.writePosition(servoValues(2));
                obj.servo3.writePosition(servoValues(3));
            end

            % EE positions
            lastRobotEEposition = [obj.model.fkine(lastVariables).t;1];
            robotEEposition = [obj.model.fkine(variables).t;1];
            


            %try to draw in the workspace
            if((lastRobotEEposition(3) <= obj.flourZactual+.1/1000) && (robotEEposition(3) <= obj.flourZactual+.1/1000))
                figure(1)
                for i = 1:2
                    subplot(2, 1, i)
                    plot([lastRobotEEposition(1), robotEEposition(1)], [lastRobotEEposition(2), robotEEposition(2)], 'r', 'LineWidth',2);  
                end
            end
        end

        % The function that performs inverse kinematics to move the End-Effector to its next location based on user input
        function moveEE(obj, unitVector, moveStep)          

            % Getting the current position of the robot
            variables = obj.model.getpos();

            % Forming the end effector's transformation matrix by using forward kinematics with 
            % the joint angles of the current robot
            EETransformationMatrix = obj.model.fkine(variables);  

            % Altering the end effector's translation vector by however much the user 
            % wants to move the end effector position and in the preferred direction
            EETransformationMatrix.t = EETransformationMatrix.t+unitVector'*moveStep;  

            % Using Inverse kinematics to determine the new joint angles
            % utilizing the altered EE transformation matrix and taking the initial guess 
            % to be the current robot angles. The initial guess is crucial to avoid useless multiple solutions
            newRobotVariables = obj.model.ikine(EETransformationMatrix, 'mask', [1 1 1 0 0 0], 'q0', variables);  

            % An if statement that checks if the new joint angles found are within the limits of the physical motors.
            % If not, the new joint angles are ignored and not plotted.
            if(~isempty(newRobotVariables)) 
                                            
                % Check if all joints are within limits
                jointsAtLimitCheck = obj.model.islimit(newRobotVariables);
                jointsWithinLimits = all(jointsAtLimitCheck(:) == 0);
                
    
                if(jointsWithinLimits)
                    % Update robot plot
                    obj.moveToPosition(newRobotVariables);
                else
                    disp("Robot is outside the limits")
                end
            else
                disp("No solutions found")
            end
            
        end

        function setRobotToSelectedPose(obj, poseName)
            newVariables = [];
            if(strcmp(poseName, 'Cap Pose'))
                newVariables = [obj.model.qlim(1, 2), obj.model.qlim(2, 1), obj.model.qlim(3, 1)];
            elseif(strcmp(poseName, 'Starting Pose'))
                newVariables = obj.startingVariables;
            end

            obj.moveToPosition(newVariables);

        end

        function obj = lowerOrRiseToWrite(obj)
            currentZ = obj.model.fkine(obj.model.getpos()).t(3);
            if(currentZ-.1/1000 <= obj.flourZactual) %%marker is lowered, so rise pen by 10 mm 
                obj.moveEE([0,0,1], 10/1000);
            else
                changeToTouch = obj.flourZactual - currentZ;
                obj.moveEE([0,0,1], changeToTouch);
            end

        end

        function obj = setCurrentZasFlour(obj)
            obj.flourZactual = obj.model.fkine(obj.model.getpos()).t(3);
        end

        function variables = getModelVariables(obj)
            variables = obj.model.getpos();
        end

        function position = getModelEEPosition(obj)
            position = obj.model.fkine(obj.model.getpos()).t;
        end

        function drawCircle(obj, centerXY, radius, steps) 
            %prepare robot by moving ee to the circle center
            currentXY = obj.model.fkine(obj.model.getpos()).t(1:2);
            XYchange = centerXY - currentXY';
            
            obj.moveEE([XYchange, 0], 1);
            
            %move to the side of the circle
            obj.moveEE([1, 0, 0], radius);
            obj.lowerOrRiseToWrite();
            
            
            previousXYEEPosition = [centerXY(1)+radius, centerXY(2)];
            for a = linspace(0, 360, steps)
              
                newXYEEPosition = [centerXY(1) + cosd(a)*radius, centerXY(2) + sind(a)*radius];
                dXYEEPosition = newXYEEPosition-previousXYEEPosition;

                obj.moveEE([dXYEEPosition, 0], 1);

                previousXYEEPosition = newXYEEPosition;

            end
            obj.lowerOrRiseToWrite();
            obj.moveEE([-1, 0, 0], radius);
        end

        function drawLine(obj, startXY, endXY, steps)
            %prepare robot by moving ee to the starting location
            currentXY = obj.model.fkine(obj.model.getpos()).t(1:2);
            XYchange = startXY - currentXY';
            
            obj.moveEE([XYchange, 0], 1);
            
            lengthsOfLineXY = endXY-startXY;
            smallChangeInX = lengthsOfLineXY(1)/steps;
            smallChangeInY = lengthsOfLineXY(2)/steps;

            obj.lowerOrRiseToWrite();
            for s = 1:steps
                   obj.moveEE([smallChangeInX, smallChangeInY, 0], 1)
            end
            obj.lowerOrRiseToWrite();
        end

        function drawCross(obj, centerXY, radius, steps)
            x = centerXY(1);
            y = centerXY(2);
            obj.drawLine([x+radius*cosd(180+45), y+radius*sind(180+45)], [x+radius*cosd(45), y+radius*sind(45)], steps);
            obj.drawLine([x+radius*cosd(180-45), y+radius*sind(180-45)], [x+radius*cosd(-45), y+radius*sind(-45)], steps);

        end

        function drawGrid(obj, x, y, width, height)
        
            obj.drawLine([x+width/3, y], [x+width/3, y+height], 10)
            obj.drawLine([x+width/3*2, y], [x+width/3*2, y+height],10)
            
            obj.drawLine([x, y+height/3], [x+width, y+height/3],10);
            obj.drawLine([x, y+height/3*2], [x+width, y+height/3*2], 10); % width*1000/2
        end

        function moveTo(obj, targetXY)
            currentXY = obj.model.fkine(obj.model.getpos()).t(1:2);
            XYchange = targetXY - currentXY';
            obj.moveEE([XYchange, 0], 1);
        end

        function obj = connectArduino(obj)
            com = char (inputdlg ('What COM Port?' , 'COM Select', 1, {'COM11'}));
            try
                obj.device = arduino (com, 'uno', 'libraries', 'Servo');
            catch
                msgbox ('Port failed', com, 'Arduino is already connected to the other model. Close the program and try again.');
                obj.device = [];
                return;
            end
            

            %connect servos
            obj.servo1 = obj.device.servo ('D9','MinPulseDuration',900e-6,'MaxPulseDuration',2100e-6);
            obj.servo2 = obj.device.servo ('D10','MinPulseDuration',900e-6,'MaxPulseDuration',2100e-6);
            obj.servo3 = obj.device.servo ('D11', 'MinPulseDuration',1500e-6,'MaxPulseDuration',1900e-6);

            %set to starting position position
            obj.setRobotToSelectedPose('Starting Pose');
        end

    end
end