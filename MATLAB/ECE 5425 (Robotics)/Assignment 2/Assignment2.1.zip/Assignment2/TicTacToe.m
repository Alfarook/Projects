classdef TicTacToe
    %UNTITLED2 Summary of this class goes here
    %   Detailed explanation goes here

    properties
        robotSystem = [];

        gridPositon = [];
        gridSize = [];

        GUIposition = [];

        playerShape = 0;
        robotShape = 0;

        %board identifyers
        %[1 2 3]
        %[4 5 6]
        %[7 8 9]
        %states: 0-circle, 1-cross, -1-nothing
        gameBoard = [];

        selectedCellMatrix = [0,0,0;0,1,0;0,0,0];

    end

    methods

        function obj = TicTacToe(GridPostionMM, GridSizeMM, robotBasePosition,startingVariables, flourZactual,...
                DHparametersAndType, jointsLimits, jointsOffsets, GUIposition)
            %TicTacToe Construct an instance of this class
            obj.gridPositon = GridPostionMM/1000;
            obj.gridSize = GridSizeMM/1000;
            obj.GUIposition = GUIposition;


            obj.robotSystem = RobotSystem(robotBasePosition, startingVariables, flourZactual,...
                DHparametersAndType, jointsLimits, jointsOffsets);

            obj.robotSystem.plotModel("Gambler", GUIposition);

            answer = questdlg("Connect Arduino?");
            if(strcmp(answer, 'Yes'))
                obj.robotSystem = obj.robotSystem.connectArduino();
            end

            %move EE to the center of the game board
            obj.robotSystem.moveTo(obj.gridPositon + obj.gridSize/2);

            %start with board filled with -1, signifying empty postions
            obj.gameBoard = ones(3,3)*-1;


            playerShapeName = questdlg('Play with...', ...
                'Player Shape', ...
                'Cross', 'Circle', 'Cross');

            obj.playerShape = 1;
            switch playerShapeName
                case 'Cross'
                    obj.playerShape = 1; %1 for cross and 0 for circle
                    obj.robotShape = 0;
                otherwise
                    obj.playerShape = 0; %1 for cross and 0 for circle
                    obj.robotShape = 1;
            end


            obj.robotSystem.drawGrid(obj.gridPositon(1), obj.gridPositon(2), obj.gridSize, obj.gridSize);

            obj.moveToCell(obj.selectedCellMatrix);
        end

        function obj = resetTheGame(obj)
            %reset plot
            obj.robotSystem.plotModel("Gambler", obj.GUIposition);

            %move EE to the center of the game board
            obj.robotSystem.moveTo(obj.gridPositon + obj.gridSize/2);

            %reset game board
            obj.gameBoard = ones(3,3)*-1;
            obj.selectedCellMatrix = [0,0,0;0,1,0;0,0,0];

            %reset player shape
            playerShapeName = questdlg('Play with...', ...
                'Player Shape', ...
                'Cross', 'Circle', 'Cross');

            obj.playerShape = 1;
            switch playerShapeName
                case 'Cross'
                    obj.playerShape = 1; %1 for cross and 0 for circle
                    obj.robotShape = 0;
                otherwise
                    obj.playerShape = 0; %1 for cross and 0 for circle
                    obj.robotShape = 1;
            end

            obj.robotSystem.drawGrid(obj.gridPositon(1), obj.gridPositon(2), obj.gridSize, obj.gridSize);
            obj.moveToCell(obj.selectedCellMatrix);
        end

        function robotIsFirst = determineIfRobotIsFirst(obj)
            robotIsFirst = randi(2) == 2;
        end

        function position = moveMatrixToCellPosition(obj, moveMatrix)
            [r, c] = find(moveMatrix, 1);

            cellPosionWithRespectToCenterCell = [r, c]-[2, 2];
            centerCellPosition = obj.gridPositon+[obj.gridSize, obj.gridSize]/2;
            position = centerCellPosition + [cellPosionWithRespectToCenterCell(2), -cellPosionWithRespectToCenterCell(1)]*obj.gridSize/3;
        end

        function obj = moveToCell(obj, moveMatrix) %move to the board postion described by passed matrix
            obj.selectedCellMatrix = moveMatrix;

            targetCellPosition = obj.moveMatrixToCellPosition(moveMatrix);
            obj.robotSystem.moveTo(targetCellPosition);

        end

        function drawO(obj) 
            postion = obj.robotSystem.getModelEEPosition();
            obj.robotSystem.drawCircle([postion(1),postion(2)], obj.gridSize/10, 10)
        end

        function drawX(obj)
            postion = obj.robotSystem.getModelEEPosition();
            obj.robotSystem.drawCross([postion(1),postion(2)], obj.gridSize/7, 4)
        end

        function obj = computeMinimaxRobotMove(obj)
            bestScore = -9999999999; %start the best score with vary low number
            bestMoveMatrix = [];

            %loop though possible board moves
            for r = 1:3
                for c = 1:3
                    if(obj.gameBoard(r, c) == -1)
                        newGameBoard = obj.gameBoard;
                        newGameBoard(r,c) = obj.robotShape;

                        newBoardMoveMatrix = zeros(3,3);
                        newBoardMoveMatrix(r, c) = 1;

                        %compute score for new game board using minimax
                        %recursion
                        score = obj.minimax(newGameBoard, true, 0);

                        if(score > bestScore)
                            bestScore = score;
                            bestMoveMatrix = newBoardMoveMatrix;
                        end
                    end
                end
            end

            obj.selectedCellMatrix = bestMoveMatrix;
            %move robot to selected cell
            obj.moveToCell(obj.selectedCellMatrix);

        end

        function score = minimax(obj, boardIteration, toMinimize, depth)
            %check winners at board iteration
            obj.gameBoard = boardIteration;
            outcome = obj.checkForWin();

            if(outcome == 1) %robot wins
                score = 10;
                return;
            elseif(outcome == 2) %human wins
                score = -10;
                return;
            elseif(outcome == 3) %tie
                score = 0;
                return;
            end

            if(toMinimize)
                score = 9999999999; %start the best score with vary high number because we try to minimize
                for r = 1:3
                    for c = 1:3
                        if(boardIteration(r, c) == -1)
                            newGameBoardIteration = boardIteration;
                            newGameBoardIteration(r,c) = obj.playerShape;

                            newDepth = depth +1;
                            iterationScore = obj.minimax(newGameBoardIteration, false, newDepth);

                            if(iterationScore < score)
                                score = iterationScore;
                            end
                        end
                    end
                end

                return;

            else
                score = -9999999999; %start the best score with vary low number because we try to maximize
                for r = 1:3
                    for c = 1:3
                        if(boardIteration(r, c) == -1)
                            newGameBoardIteration = boardIteration;
                            newGameBoardIteration(r,c) = obj.robotShape;

                            newDepth = depth +1;
                            iterationScore = obj.minimax(newGameBoardIteration, true, newDepth);

                            if(iterationScore > score)
                                score = iterationScore;
                            end
                        end
                    end
                end

                return;
            end
        end

        function [obj, message, isValid] = playerTurn(obj)
            [targetCellR, targetCellC] = find(obj.selectedCellMatrix, 1);
            %check is cell is empty
            if(obj.gameBoard(targetCellR, targetCellC) == -1)
                obj.gameBoard(targetCellR, targetCellC) = obj.playerShape;
                if(obj.playerShape == 0)
                    obj.drawO();
                else
                    obj.drawX();
                end

                message = 'You made a turn.';
                isValid = true;
            else
                message = 'Cell is already played. Select another cell and try again.';
                isValid = false;
            end
        end

        function obj = robotTurn(obj)
            [targetCellR, targetCellC] = find(obj.selectedCellMatrix, 1);

            %update game board
            obj.gameBoard(targetCellR, targetCellC) = obj.robotShape;

            if(obj.robotShape == 0)
                obj.drawO();
            else
                obj.drawX();
            end

        end

        function outcome = checkForWin(obj)          %possible outcomes: 0 - no win/tiw, 1 - robot wins, 2 - user wins, 3 - tie      
            outcome = 0;

            %while loop to isolate winning identifyers
            while(true)
                playerWon = false;
                robotWon = false;
                %check game board rows
                for r = 1:3
                    playerWon = all(obj.gameBoard(r, :) == obj.playerShape);
                    robotWon = all(obj.gameBoard(r, :) == obj.robotShape);

                    %determine outcome
                    if(robotWon)
                        outcome = 1;
                        break;
                    elseif(playerWon)
                        outcome = 2;
                        break;
                    end
                end


                %check game board columns
                for c = 1:3
                    playerWon = all(obj.gameBoard(:, c) == obj.playerShape);
                    robotWon = all(obj.gameBoard(:, c) == obj.robotShape);

                    %determine outcome
                    if(robotWon)
                        outcome = 1;
                        break;
                    elseif(playerWon)
                        outcome = 2;
                        break;
                    end
                end


                %check game board diagonals
                diagonal1 = [];
                diagonal2 = [];
                for i = 1:3
                    diagonal1(end+1) = obj.gameBoard(i, i);
                    diagonal2(end+1) = obj.gameBoard(4-i, i);
                end
                playerWon = all(diagonal1 == obj.playerShape);
                robotWon = all(diagonal1 == obj.robotShape);

                %determine outcome
                if(robotWon)
                    outcome = 1;
                    break;
                elseif(playerWon)
                    outcome = 2;
                    break;
                end

                playerWon = all(diagonal2 == obj.playerShape);
                robotWon = all(diagonal2 == obj.robotShape);

                %determine outcome
                if(robotWon)
                    outcome = 1;
                    break;
                elseif(playerWon)
                    outcome = 2;
                    break;
                end

                break;
            end

            %if no winners detected, check for tie
            if(outcome == 0)
                %try finding empty cell
                index = find(obj.gameBoard == -1);
                if(isempty(index))
                    outcome = 3;
                end
            end
        end

    end
end

